import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OrderCancellationService {

  constructor(private http:HttpClient) { }

  public getOrders(){
    return this.http.get("http://localhost:9000/getAllOrders");

  }
  public cancelOrder(orderId:number){
    return this.http.delete("http://localhost:9000/cancelOrder/"+orderId);
  }
 
}
