export class order{
    constructor(
        orderId:number,
        orderDateTime:String,
        orderStatus:String



    ){}
}