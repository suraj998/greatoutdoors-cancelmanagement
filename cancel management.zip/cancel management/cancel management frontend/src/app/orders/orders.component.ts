import { Component, OnInit } from '@angular/core';
import { OrderCancellationService } from '../order-cancellation.service';
import { Router } from '@angular/router';
import { StylesCompileDependency, analyzeAndValidateNgModules } from '@angular/compiler';
import { I18nSelectPipe } from '@angular/common';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  orders:any;
  constructor(private service:OrderCancellationService,private router:Router) { }

  public deleteOrder(orderId:number){
    
    let confirmation=confirm("Are you sure you want to delete this order ?");
    if (confirmation) 
    {
      let resp=this.service.cancelOrder(orderId);
    resp.subscribe((data)=>this.orders=data);
    confirm("Desired order has been cancelled !");
    this.router.navigateByUrl("/refresh");
    }

  }
  delay(arg0: number) {
    throw new Error("Method not implemented.");
  }


  ngOnInit() {
    let resp=this.service.getOrders();
    resp.subscribe((data)=>this.orders=data);
  }

}
