package com.cg.greatoutdoors.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.greatoutdoors.entity.Order;


@Repository
@Transactional
public class OrderDaoImp implements OrderDao {
	
	@PersistenceContext
	EntityManager entitymanager;
	
	/************************************************************************************
	 * Method:  					fetchOrders
     * Description: 				To retrieve all the orders from the orders table
	 * @returns list<>              returns the list of all the orders
	 * @throws AccountException     
                *Created By                              - Suraj Joshi
                *Created Date                            - 17-APR-2020                           
	
	 ************************************************************************************/


	@Override
	public List<Order> fetchOrders() {
		
		Query query=entitymanager.createQuery("select o from Order o");
		List<Order>list=query.getResultList();
		return list;
	}

	
	/************************************************************************************
	 * Method:  					CancelOrders
     * Description: 				To cancel  the selected order from the orders table and returns
									the id of the order that has been cancelled
	 * @returns integer             returns the orderId of the cancelled or deleted order
	 * @throws AccountException     
                *Created By                              - Suraj Joshi
                *Created Date                            - 17-APR-2020                           
	
	 ************************************************************************************/

	
	@Override
	public int cancelOrder(int id) {
		
		Order order=entitymanager.find(Order.class, id);
		if(order!=null)
		{
			entitymanager.remove(order);
			return order.getOrderId();
		}
		else
		{
			return 0;
		}
		
		
	}
	

}
