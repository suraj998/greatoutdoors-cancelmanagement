package com.cg.greatoutdoors.service;

import java.util.List;

import com.cg.greatoutdoors.entity.Order;

public interface OrderService {
	public List<Order> fetchOrders();

	

	public int orderCancel(int id);

	
}
