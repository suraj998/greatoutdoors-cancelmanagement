package com.cg.greatoutdoors.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.greatoutdoors.dao.OrderDao;
import com.cg.greatoutdoors.entity.Order;

@Service
@Transactional
public class OrderServiceImp implements OrderService {

	@Autowired
	OrderDao cancelorder;  
	@Override
	public List<Order> fetchOrders() {
		// TODO Auto-generated method stub
		return cancelorder.fetchOrders();
	}
	@Override
	public int orderCancel(int id) {
		// TODO Auto-generated method stub
		return cancelorder.cancelOrder(id);
	}

}
