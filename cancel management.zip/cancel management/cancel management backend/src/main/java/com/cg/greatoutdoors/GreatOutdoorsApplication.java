package com.cg.greatoutdoors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreatOutdoorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreatOutdoorsApplication.class, args);
	}

}
