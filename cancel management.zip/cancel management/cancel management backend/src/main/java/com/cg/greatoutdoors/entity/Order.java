package com.cg.greatoutdoors.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "ALL_ORDERS")
public class Order {
	 @Id
	 @GeneratedValue
	    @Column(name="ORDER_ID",unique = true, nullable = false)
	    private int orderId;
	    
	    @Column(name="ORDER_STATUS", unique=false, nullable= false)
	    private String orderStatus;
	    
	    
	    @Column(name="ORDER_DATETIME", unique=false,nullable=false)
	    private String orderDateTime; 
	    
	 
	    public Order() {
	        super();
	    }


public Order(int orderId, String orderStatus, String orderDateTime ) {
    super();
    this.orderId = orderId;
    this.orderStatus = orderStatus;
    this.orderDateTime = orderDateTime;
  
}



public int getOrderId() {
    return orderId;
}



public void setOrderId(int orderId) {
    this.orderId = orderId;
}



public String getOrderStatus() {
    return orderStatus;
}



public void setOrderStatus(String orderStatus) {
    this.orderStatus = orderStatus;
}



public String getOrderDateTime() {
    return orderDateTime;
}



public void setOrderDateTime(String orderDateTime) {
    this.orderDateTime = orderDateTime;
}

}
