package com.cg.greatoutdoors.dao;

import java.util.List;

import com.cg.greatoutdoors.entity.Order;

public interface OrderDao {
	public List<Order> fetchOrders();

	public int cancelOrder(int id);

	
	

}
