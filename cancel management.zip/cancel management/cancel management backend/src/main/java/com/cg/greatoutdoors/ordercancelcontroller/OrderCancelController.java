package com.cg.greatoutdoors.ordercancelcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.greatoutdoors.entity.Order;
import com.cg.greatoutdoors.service.OrderService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class OrderCancelController {
	@Autowired
	OrderService orderservice;
	
	
	//call the url from front end and fetch the result of table and show the result on screen.
	@GetMapping("/getAllOrders")
	public ResponseEntity<List<Order>> orderDetails()
	{
		List<Order> list=orderservice.fetchOrders();
		
		return new ResponseEntity<List<Order>>(list,HttpStatus.OK);	
		
	}
	
	@DeleteMapping("/cancelOrder/{orderId}")
	public ResponseEntity<Integer> addProduct(@PathVariable int orderId){
		
		int pid=orderservice.orderCancel(orderId);
		
		return new ResponseEntity<Integer>(pid,HttpStatus.OK);
		
		
	}
	
	
	}
	
	


